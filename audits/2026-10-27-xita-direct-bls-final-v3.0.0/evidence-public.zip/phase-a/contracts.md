# Phase A - independent smart-contract examination

Status: COMPLETE for the independent contract workstream, before historical reassessment. No historical audit files or remediation reports were read. Source comments were treated as implementation claims, not proof. The parent audit combines these notes with other independent workstreams before freezing Phase A.

## Scope and reproducibility

- Repository: `xgr-network/xgr-interchain`, frozen `main` commit `ffc24139738bcb25ab516e5d3242f258a75fcfb8`.
- Reviewed all 21 production Solidity files (approximately 2,978 lines), production interfaces, the pinned Hyperlane Mailbox/Router/TokenRouter inheritance paths, and the 15 Solidity test files (16 test suites).
- The parent independently checked every frozen source blob against the connected GitHub tree. Testbed sources were copied from this snapshot; the snapshot itself was not modified.
- Local tools: Forge 1.5.1-stable (`b0a9dd9ceda36f63e2326ce530c10e6916f4b8a2`), Solidity 0.8.24 (`e11b9ed9`), optimizer 200, via IR. Forge normalizes the compiler EVM target to Cancun for this compiler; EIP-2537 execution tests pass in the configured test EVM. Additional boundary tests explicitly request the Prague runtime.
- Cached packages match the exact declared versions: Hyperlane core 11.1.0, OpenZeppelin contracts and contracts-upgradeable 4.9.3. Forge test utilities are 1.9.2. Version fingerprints are recorded in `dependencies.json`; a fresh npm registry tarball integrity check was not performed.

## Independent risk observations

### C-A01 - Native message delivery does not imply immediately spendable recipient balance

**Proposed current severity:** Medium for an interface that reports completed native delivery as wallet availability without recognizing deferred claims. **Priority:** P1 for supported contract-wallet recovery; not a principal-custody issue.

`contracts/XETAGuardedNativeWarpRouter.sol:68-85` protects collateral, attempts a native payment with 30,000 gas, and if the recipient rejects the payment, records a backed `pendingNativeXGR[recipient]` claim while returning success. The real Hyperlane Mailbox stores `delivered(messageId)` and calls the recipient router in the same successful transaction (pinned Mailbox implementation lines 215-245). Therefore a perfectly valid delivery can complete while the beneficiary wallet balance remains unchanged.

The beneficiary can call `withdrawPendingNativeXGR(address payable)` to redirect or receive the reserved funds; only the beneficiary contract itself is authorized, not an externally owned account that happens to control it (`XETAGuardedNativeWarpRouter.sol:25-38`). A general-purpose smart wallet can issue that call. An arbitrary recipient contract lacking such an execution facility cannot be assumed able to claim.

The application/indexer source search found no handler for `pendingNativeXGR`, `withdrawPendingNativeXGR` or `NativeDeliveryDeferred`; only the TVL worker reads the aggregate reservation. The parent is assessing the exact displayed status paths. The contract fallback itself preserves funds and improves liveness; the issue is the interface/claim workflow and supported-wallet boundary.

**Independent check:** `testMailboxDeliveredCanMeanReservedClaimNotWalletBalance` uses the real Mailbox and real native router with an explicitly test-only accepting ISM. It verifies delivered=true, wallet balance zero, an exactly backed pending claim, replay rejection, beneficiary-authorized alternate payout and no residual debt. The test does not claim to verify BLS authentication; that boundary is independently exercised by the existing cryptographic tests.

### C-A02 - Recovery-admin and online-service roles can converge after deployment

**Proposed severity:** Low. **Priority:** P2. **Disposition:** OPEN as a hardening gap; no unprivileged escalation.

`contracts/XITAExecutionGateway.sol:130-155` requires an independent recovery administrator at creation and rejects rotation of the service wallet to the current owner. However the inherited `Ownable2Step.transferOwnership` / `acceptOwnership` route has no corresponding exclusion. An authorized recovery administrator can nominate the current service wallet; that wallet can accept, leaving `owner() == serviceWallet()`.

This requires an administrator action. It does not give the service signer control over user principal, and the current live reads supplied by the parent show distinct roles on all three chains. It weakens the documented recovery property if an operator uses an otherwise valid ownership-transfer workflow. An on-chain guard on nomination or acceptance, plus a deployment/health invariant for owner/pendingOwner/serviceWallet, would retain the intended separation. Record as an operationally avoidable risk, not as a launch-blocking exploit.

**Independent check:** `testInheritedOwnershipTransferCanCollapseRecoveryKeySeparation` performs the authorized two-step transition and observes equal roles.

### C-A03 - Membership authorizations have a residual cross-deployment replay domain

**Proposed residual severity:** Medium if two matching registries are simultaneously active for the same chain/domain; operationally bounded when exactly one registry is active. **Priority:** P1 invariant before operating parallel deployments.

`XGRInterchainValidatorRegistryV3.sol:428-460` signs chain ID, destination domain, set ID, expiry, action, validator address and both key encodings, but not the registry contract address. Two deployments with the same chain/domain, membership and set ID therefore produce identical signing bytes. A valid membership authorization can be submitted to both while unexpired. This does not forge a BLS signature and does not permit transfer-message replay: Direct-BLS transfer signing bytes explicitly include both destination ISM and destination registry addresses (`XITADirectProtocol.sol:42-49`).

The 10-minute maximum membership validity, current set ID and quorum checks constrain the condition (`ValidatorRegistry:376-415`), but do not cryptographically eliminate cross-registry replay. The operating invariant is one active destination registry per chain; if parallel deployments or migration overlap are introduced, bind membership signatures to a deployment address and version the protocol deliberately. Whether this invariant is accepted and verified operationally is assessed by the parent.

**Independent check:** `testMembershipPayloadIsIdenticalAcrossMatchingRegistryDeployments` establishes identical payloads and shows both contracts apply the same simulated quorum-approved transition. This test uses an explicit mock verifier, so it proves the replay-domain/state-machine property; it is not represented as a newly computed real BLS forgery.

### C-A04 - Minimum committee size is an operating policy, not a contract invariant

**Proposed severity:** Low as a configuration/operations risk, rising with actual insecure deployment. **Priority:** P1 to monitor minimum active membership, P2 to consider contract enforcement.

Bootstrap accepts any nonempty set (`ValidatorRegistry:122-135`). Removals are prevented only when at most one member remains (`:630-631`). The quorum formula correctly implements `ceil(2n/3)` (`:306-308`, `:333-335`), so a one-member registry has a one-signature quorum. No unprivileged caller can shrink the set: removals require the current authorized BLS quorum. The parent live reads observed three members and threshold two on all three chains; this is not a present single-validator launch defect.

A controlled launch should preserve at least three independently operated members, monitor concentration, and retain current-set re-attestation availability. Permanent loss of a quorum cannot be solved by a privileged administrator in these ownerless registries. Permissionless execution still depends on obtaining valid current-set authorization.

**Independent check:** `testSingleValidatorBootstrapAndOneSignerQuorumAreAllowed`; direct negative quorum cases in `testQuorumRejectsUnderweightNonCanonicalAndOutOfRangeBitmaps`. Cryptographic verification is mocked to isolate quorum policy.

### C-A05 - One repository topology test misplaces its expected revert

**Proposed severity:** Informational. **Priority:** P2 test repair. **Status:** reproducible local fixture failure, not an identified factory-guard bypass.

The unmodified suite produced 102 passing tests and one failure: `testFactoryRejectsMismatchedHubIdentityAtDeployment`. At `test/XITAXGRHubTopologyV315.t.sol:88-93`, `vm.expectRevert` precedes three successful router-deployer constructor calls evaluated as arguments of the factory constructor. The expectation is consumed by a helper creation before the intended factory call. The production factory guard (`XETATokenFactoryV315.sol:61-68`) rejects the mismatched hub identity directly. The local isolated reproduction creates the three helpers before arming the expectation; the intended factory rejection then passes. Its result is recorded separately. This must not be summarized as an all-green unmodified repository suite.

## Verified security boundaries and important positive results

| Boundary | Evidence and independent assessment |
| --- | --- |
| Current-set authorization | `XITADirectBLSISM:52-64` rejects retired destination set IDs before cryptographic verification. Re-attestation uses the current set; a second source lock is not required. |
| Exact message binding | ISM checks source domain, destination, source router, destination router and message Keccak (`:66-74`). The complete fixed-width authorization also binds route, source registry/gateway/mailbox, fee, source block, destination ISM and destination registry (`XITADirectProtocol:25-50`). |
| Asset ownership at destination | The actual recipient router recomputes its expected reverse route using its own registered asset ID and exact router pair (`XETARouterCore:104-131`). A BLS payload for another asset cannot unlock a different router. |
| BLS key/PoP discipline | Bootstrap and ADD require proof of possession, compressed-to-EIP-2537 key consistency in EIP mode, active-key uniqueness and current-set quorum (`ValidatorRegistry:72-94,164-204,601-625`). The real verifier rejects identity public keys, identity signatures and identity aggregate keys (`BLSVerifier:30-89`). Actual single-key, aggregate and changed-message vectors passed. |
| Quorum bitmap | The registry rejects zero/oversized/noncanonical bitmap encodings and bits outside the set; threshold is calculated from the selected immutable snapshot (`ValidatorRegistry:315-343,682-713`). |
| Replay and failed delivery | Hyperlane Mailbox checks `delivered`, records it before external calls and reverts the entire transaction on failed authentication/handling. The router requires the configured Mailbox and enrolled sender. Current-set and per-deployment message binding add independent boundaries. |
| Gateway-only outgoing movement | All public router transfer paths reach the internal `_transferRemote` override, which requires the canonical registry gateway and enrolled destination (`XETARouterCore:134-153`). The synthetic multiple-inheritance override delegates explicitly to this check. |
| No centralized principal custody | Native/collateral/synthetic routers have ownership initialized to zero. Escrow unlock/mint is driven by authenticated Mailbox delivery; a service fee signer or recovery administrator has no principal sweep or forced-transfer capability. |
| Supply and escrow | Native principal is quoted once; exact token debit/balance increase is required for the collateral path; synthetic supply starts at zero and can increase only through the inherited authenticated handler. Two-hop accounting cases with native XGR, original ERC20s and six decimals passed. |
| Pending native funds | Native payout checks balance minus previous pending claims before attempting new payment; insufficient collateral reverts instead of creating an unbacked claim. Eight existing fallback/reservation tests passed. |
| Atomic fees | Canonical fee payment, lock/burn, dispatch and FeeVault allocation execute atomically (`ILNGateway:179-237`). Duplicate operation allocation is rejected. Transfer-time fee allocation is O(1) rather than O(validators). |
| Fee withdrawal | Historical membership snapshots, per-epoch accumulation and paginated claims prevent rotating memberships from confiscating old fees. CEI and reentrancy protection prevent repeated withdrawal (`FeeVault:94-195`). |
| EIP-712 | Payer, gateway, route, amount, recipient and onward identity are signed; EIP-712 binds chain and execution contract. Nonces are payer-scoped, consumed atomically, and rolled back on failure; issuedAt is not future-dated and lifetime cannot exceed 90 seconds (`ExecutionGateway:178-247`). |
| Service failure independence | Users can use the public ILN gateway without the optional service adapter. Service-wallet key rotation invalidates old quotes without changing router custody or validator verification. |
| Hub topology | Protocol route IDs and factory registration require exactly one XGRChain endpoint, checking chain and domain identity together (`XGRILNProtocol:35-55`, `Factory:192-228`). |
| CREATE2 preemption | All three public deployer modules namespace their salt with `msg.sender`; direct calls by another account cannot occupy a factory's deployment address. |

## Runtime-to-source comparison

The parent collected canonical-block-pinned `eth_getCode` results and independently matched 57 live contract records to receipt hashes. This workstream then compared those bytes with freshly compiled frozen source:

- All 57 runtime lengths match.
- Every observed byte outside compiler-declared immutable spans and precisely recognized Solidity 0.8.24 IPFS metadata digest spans matches the locally compiled bytecode.
- 45 comparisons differ only in the final metadata digest. Twelve factory/router-deployer comparisons additionally contain digest differences inside embedded child-contract creation data.
- There are no remaining instruction-byte differences after these narrowly specified exclusions.
- This is **not** a byte-for-byte metadata reproduction and **does not** verify the excluded immutable values. Immutable/configuration bindings must be checked through getters, constructor/deployment evidence and their callers separately. The parent owns those live configuration checks.
- The comparison records every excluded span, contract address, pinned block, artifact SHA-256, compiler settings and comparison result in `runtime-comparison.json`. It does not silently apply the production deployment verifier's stricter acceptance policy to different build metadata.

## Underlying-token and liveness assumptions

The protocol's standard ERC20 accounting cannot make an arbitrary original token trustworthy. Negative rebases, token-admin seizure/blacklisting, pausing, upgrades and behavior changes can reduce escrow availability or block redemptions. Initial exact-debit checks reject an immediate fee-on-transfer mismatch; they cannot prevent later token policy changes. Asset-specific exposure is isolated to its independently registered router; it does not authorize spending another asset's collateral. Public listing and user disclosures should reflect supported token semantics.

No source-code review can independently prove separate physical operators for the current BLS members, retained validator keys, actual installed node binaries or future quorum availability. The optional service administrator has no unilateral refund/sweep path for router principal. Recovery remains dependent on source evidence, current authorization and a functioning destination chain.

## Test and evidence inventory

- `forge-run-2.log`: unmodified frozen repository tests; 102 pass / 1 fixture failure / 0 skipped; actual EIP-2537 vectors pass.
- `forge-full.log`: first setup attempt lacking forge-std; resolved by adding the installed test dependency to the isolated testbed. No source bug is attributed to this environment failure.
- `forge-independent.log`: first independent harness run; five policy/boundary tests pass; fuzz recipient addresses accidentally selected EIP precompiles and correctly hit TransferFailed.
- `forge-independent-final.log`: 7 passing tests / 0 failures, including six independent boundary tests and the isolated topology expectation. The FeeVault property ran 257 cases (one persisted counterexample plus the configured 256 generated cases), each covering 40 epochs and paginated withdrawals.
- `fixture-adjustment.txt`: complete explanation of local harness changes; production snapshot untouched.
- `dependencies.json`: pinned package/version fingerprints.
- `runtime-comparison.json`: independent source/runtime comparison for all 57 observed deployed instances.

This review has not identified a permissionless mint, collateral theft, BLS membership bypass, replay double-payment or direct spoke-to-spoke execution path in the examined contract implementation. This is a bounded audit result, not a proof of absence. Source-observation authenticity, sponsorship accounting and production readiness are examined in the other workstreams.
