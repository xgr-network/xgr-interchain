# Phase A - Independent integration, release and production review

This record was completed before either historical audit or a remediation narrative was opened. It supplements the independent contract, node and sponsorship records without replacing their findings. Only the two authorized source snapshots were examined: xgr-network/xgr-interchain main at ffc24139738bcb25ab516e5d3242f258a75fcfb8 and xgr-network/xgr-node XGR3.0 at 4d341a08baa604c7871e10af8c7c2e2406f4d032.

## L-A01 - Delivery transaction data is not independently bound to the selected message in the browser

**Severity: Low. Priority: P2. Disposition: OPEN, defense in depth.**

The delivery action checks the proof response's messageId, destination Mailbox, chain, process selector and zero transaction value. It does not decode the message inside the returned process calldata and recompute that message's ID before presenting it to the wallet. The indexer's response check follows the same metadata boundary. See apps/web/transfer-actions.js:614-674 and services/indexer/transfer-recovery.mjs:65-87.

The honest native-relayer proof construction validates the actual complete message and its authorization, and the real destination Mailbox cryptographically authenticates any transaction submitted to it. This is consequently not a signature bypass or principal redirection finding. A compromised proof response could cause a wallet to spend gas delivering another independently valid message while the selected transfer remains unfinished. The claim is based on source review, not an executed malicious browser or mainnet transaction. Decode and bind both authorization and message to the selected record before signing. Retain contract verification as the authority.

## L-A02 - Full regression results differ from the selected CI coverage

**Severity: Low. Priority: P2. Disposition: OPEN.**

All 39 browser-unit test files were invoked individually under Node 24.22.1 with named-test reporting: 280 tests, 273 passes and seven failures. Two failures arise because Chromium is absent in the audit environment; these are unexecuted browser checks, not product failures. Five assertions have stale expected token addresses, route count or recovery-button wording. The source/catalog use the current address and eight routes. The indexer group produced 136 passes and one stale assertion rejecting a pinned eth_call which another current test intentionally permits. The full Solidity suite has the separate expected-revert fixture defect C-A05. None of these assertions independently establishes a production authorization failure.

The selected lists in .github/workflows/validate.yml do not cover every discovered test. Repair obsolete expectations against current public behavior and make discovery/coverage explicit. Keep the genuine failed unmodified runs in evidence. Do not summarize the entire repository as green. Browser execution, real wallet interoperability, account-abstraction paths and a live end-to-end transfer matrix remain unverified.

## L-A03 - Production readiness is incomplete and installed software identity is unproven

**Severity: Medium operational gap. Priority: P1; specific source/accounting release gates remain P0 under NODE-A-01. Disposition: OPEN.**

Read-only observations at 2026-10-27T07:17:51.860Z through 07:18:10.139Z show the paid quote endpoint reporting ready but sponsorship.available=false on XGRChain, Base and Arbitrum, reason sponsor-reserves-or-worker-not-ready. This is an actual advertised-service readiness restriction. It does not prove which source defect, reserve level, database role or worker condition caused it. A self-funded restricted service can be evaluated separately from any promise of sponsored, low-gas-wallet operation.

The public XGR endpoint reports xgrchain/v3.3.8/linux-amd64/go1.23.11 and an alive, caught-up observer across eight routes. Neither observation proves every signing validator runs the published binary, nor that a current-set authorization can actually be obtained during failures. The proofBuilder installed health field confirms executable availability, not successful quorum formation. Actual host binary hashes, environment/service versions, database roles, independent validator operation, secret separation, storage recovery and real wallet journeys were not accessible.

The independently downloaded v3.3.8 release points to the frozen node SHA. Its 73,021,839-byte Linux binary hashes to 95fd72cc72b942d206b130ff4ef63df83d2d161a99d092cd68b9b240c6be9617, matching both published asset metadata and sha256sums.txt. Embedded Go build metadata reports that revision and vcs.modified=false. This verifies release correspondence and download integrity, not a bit-reproducible source build or installed-host attestation.

## Independent live deployment evidence

All nine configured RPC endpoints responded successfully to read-only identity/head checks through the environment's required proxy. An earlier run without that proxy failed because of the audit environment; it is not evidence of a network outage. Base and Arbitrum safe heads were observed. A lagging Base endpoint had an older valid safe head, not a contradictory hash at the same height.

At fixed per-chain blocks, 57 unique deployed contract runtimes matched all recorded receipt Keccak-256 hashes. The block headers were reread and remained unchanged. Fresh source compilation compared all 57 bodies with no unexplained instruction differences after excluding declared immutables and precisely identified Solidity metadata digests. This is not byte-exact compiler metadata reproducibility. Additional route/getter checks may supplement the final verification record after this freeze; they cannot retroactively alter these independent findings.

All three live validator registries reported set ID 1, three members and threshold two. All three Execution Gateways reported distinct owner and service-wallet roles and a 90-second quote lifetime. Default Mailbox ISMs matched deployment receipts. The production catalog.json and app.js matched the frozen source exactly. This does not attest every other frontend module or backend installation.

## Integration and recovery assessment

The ordinary flow has two core user-authorized transactions for one hop and four for two hops. ERC20 allowance transactions, if needed, are additional. Browser code uses an EIP-1193 provider, including generic wallet requests; source review is not a certification of every browser wallet, mobile connector, hardware wallet or account-abstraction execution model.

The source and onward transaction paths verify account, chain, nonce, source receipt, destination route and fee/gas readiness before signing. Two-hop parent-message binding and the on-chain onwardParentUsed guard prevent a duplicate onward operation. Local storage contains bounded public transaction locator hints and is not the authorization source. Recovery reobtains current evidence and current-set authorization; user principal is held in authenticated router escrow, not a service treasury.

The native-router fallback in C-A01 creates a backed beneficiary claim, while transfer-status-flow.js:119-145 describes confirmed Mailbox delivery as complete with no further wallet action. That wording is incorrect for a recipient requiring the deferred native claim. A general smart wallet able to execute the claim can recover to an alternate destination; an arbitrary receiver contract cannot be presumed to have that ability. This is a supported-recipient and status/claim-workflow restriction.

Backend optional failures can block convenient progress without giving those services custody of principal. Recovery still needs functioning chains, available current validator quorum and sufficient transaction gas. Neither immutable contracts nor independent wallet access can recover from permanent loss of validator quorum by themselves.

## Residual observations retained for final inventory

The sponsorship record additionally preserves single-RPC expiry-release evidence, unauthenticated reservation capacity, conservative daily-limit double counting, an unpaid onward grant becoming ineligible after external early delivery, obligations remaining after sponsorship shutdown, and the separately configured legacy relay execution mode. They must be mapped explicitly during final consolidation rather than silently discarded.

The contract record preserves membership signatures' cross-deployment replay domain, minimum committee size as an operating invariant, authorized owner/service role convergence and arbitrary underlying-token behavior. These are distinct from a demonstrated unprivileged principal-theft path.

## Scope and safety limitations

No live transaction, malicious consensus proposal, deployment, configuration alteration or asset transfer occurred. The automated security filter interrupted deeper exploit-oriented node reproduction. Completed local observations and source traces are described with their limits. Runnable node checks and detailed accounting outputs are segregated for confidential archival; public evidence contains existing standard/race tests and sanitized conclusions. The full end-to-end consensus exploit and installed-validator exposure were not verified. This limitation does not close the statically evidenced P0 accounting boundary.

No historical audit was used to select these findings. The next phase may add corroboration, reassess old issues, and consolidate duplicate findings, but this record will remain unchanged.
