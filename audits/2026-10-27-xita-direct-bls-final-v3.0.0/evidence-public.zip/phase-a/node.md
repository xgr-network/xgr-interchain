# Phase A - Independent node security review

**Frozen repository:** `xgr-network/xgr-node`, branch `XGR3.0`, commit `4d341a08baa604c7871e10af8c7c2e2406f4d032`.

**Method:** independent source and test review before reading either historical audit or their remediation notes. Source comments referring to older issues were visible as part of implementation, but historical reports were not used to derive these findings. All tests ran against a local copy; the frozen source tree and production systems were not changed.

**Scope:** Direct-BLS encoding, source witnesses/finality, native committed-state adapter, membership and aggregation, signer entry points, gossip admission, shared observer and retries, persistence, transport cancellation, and the underlying node accounting/IBFT integration boundaries. Provider corporate/upstream independence, installed production binaries and on-chain deployments are assigned to the lead auditor.

## Executive result

The transport authorization path has substantial protections: canonical full-operation evidence, distinct configured operator identities, exact witness comparisons, locally committed XGR evidence, current destination membership, signature domain separation, and destination delivery checks. The reviewed signing call graph does not reveal an alternate external-source signing path that bypasses witness verification.

The independent node review nevertheless identifies a **High, P0 underlying execution/accounting issue** in the frozen source, supported by local execution observations and a source trace through block processing. This is separate from the external RPC trust assumption. Public launch approval must not infer native principal integrity merely from passing Interchain regression tests. A complete malicious network proposal was not created or broadcast, and installed-validator vulnerability was not established by this workstream.

Additional residual issues concern cross-transaction gas accounting, adversarial gossip workload, and fairness/isolation of the retry backlog. They affect distinct boundaries and should not be conflated with the RPC witness mitigation.

## Independent findings

### NODE-A-01 - Native system-transaction accounting and proposal validation boundary

- **Current severity:** High. **Priority:** P0. **Disposition:** OPEN.
- **Boundary:** native asset supply/accounting and the block-proposer-to-honest-validator execution boundary.
- **Current evidence:** the execution path for nonstandard system transactions does not establish ordinary fee funding before the later fee/refund accounting branch. The nominal zero-fee interpretation and the effective-price helper are inconsistent. Block-body processing distinguishes a single canonical system-transaction form, but other system-transaction forms remain exposed to ordinary execution. The reviewed block/header validation also lacks an explicit equality check against the deterministic expected base fee.
- **Source anchors:** `state/executor.go:183-212`, `425-447`, `735-777`, `820-835`, `1545-1578`; `types/transaction.go:239-265`; `consensus/ibft/fork/hooks.go:149-169`; `consensus/ibft/ibft.go:468-522`; `blockchain/blockchain.go:644-690`; `types/rlp_unmarshal.go:564-574`.
- **What was actually verified:** before the automated security interruption, isolated local accounting checks observed creation of unfunded credits in the relevant execution path, including a round-tripped transaction processed by the actual `Executor.ProcessBlock` function with supported forks enabled. Source tracing shows the mempool rejection is a separate boundary and is not a substitute for block validation. These checks were not a network-consensus exploit, were not run against production, and did not establish which binary is currently installed on validators.
- **Impact/prerequisites:** a proposer-controlled block path is a privileged prerequisite. If the reviewed behavior is reachable in the deployed network, native supply and fee accounting can be invalidated, which also undermines the economic backing of interchain native-token transfers. No unprivileged wallet theft or remote compromise of validator keys is claimed.
- **Required remediation:** explicitly constrain admissible system transactions at consensus/block validation; make system transactions non-fee-bearing throughout execution; enforce deterministic header base-fee validation; add regression assertions for native-supply conservation and rejection of invalid system transaction forms. Verify the corrected published binary and each installed validator build separately.
- **Publication handling:** runnable reproduction material and detailed local outputs have been segregated from public evidence. The public report should contain this sanitized security boundary, impact, source references, and remediation only.

### NODE-A-02 - Transaction-original storage/refund accounting does not reset consistently

- **Current severity:** Medium. **Priority:** P1. **Disposition:** OPEN.
- **Boundary:** transaction-local storage gas and refund accounting within a block.
- **Current evidence:** `GetCommittedState` reads the underlying snapshot, while transaction cleanup resets refunds without replacing the transaction-original storage baseline. The subtraction helper uses unsigned arithmetic without an underflow guard. These properties permit an inconsistent refund state across transactions.
- **Source anchors:** `state/txn.go:221-287`, `449-457`, `480-488`, `550-584`; `state/executor.go:479-483`; `state/runtime/runtime.go:123-132`.
- **Verification:** an isolated state-accounting check observed the unsigned refund wrap before the automated security interruption. A complete multi-transaction EVM/network reproduction was not performed. The refund application itself is capped at half of gas used; this finding therefore does **not** establish unlimited refunds, arbitrary minting, or unlimited execution from the refund issue alone.
- **Impact/prerequisites:** multiple storage updates in separate transactions in one block can lead to incorrect gas charging/refund treatment. Consensus participants running identical code may agree on incorrect accounting; agreement alone is not correctness.
- **Required remediation:** maintain a per-transaction original-state snapshot or equivalent original-slot journal, enforce refund arithmetic invariants, and add cross-transaction storage gas tests. Any protocol-level change needs coordinated rollout under the chain's fork policy.

### NODE-A-03 - Expensive gossip verification precedes admission controls

- **Current severity:** Medium. **Priority:** P1. **Disposition:** OPEN.
- **Boundary:** untrusted P2P messages versus finite Interchain RPC, CPU and goroutine capacity.
- **Source anchors:** `interchain/runtime/worker.go:830-880`; `interchain/runtime/iln_checkpoint.go:168-201`; `interchain/runtime/iln_quorum_request.go:248-281`; `network/gossip.go:108-122`.
- **Evidence:** checkpoint votes resolve a route and invoke full source-evidence acquisition before voter membership and BLS signature validation. Peer quorum hints also invoke the normal proof path directly. The dedicated per-peer throttle applies to completed-quorum frames and route notices, but not to these other expensive frame types. The shared gossip implementation starts a goroutine per delivered message.
- **Verification:** a bounded local seam check confirmed that frames without a usable signer signature reached source-evidence acquisition. No live P2P saturation test, flood, or production traffic was generated. Existing transport deadlines and response-size limits are real mitigations, but do not bound aggregate admitted work.
- **Impact:** resource/RPC exhaustion and delayed valid transfers; no invalid signature or unauthorized mint was observed. The optional worker is outside synchronous IBFT verification hooks, but shares process and host resources, so total resource isolation is not established.
- **Required remediation:** cheap shape/signature/member checks where safely cacheable, per-peer and global admission limits before remote reads, bounded concurrency, fair queues and in-flight deduplication. Preserve complete source verification before any actual local signature.

### NODE-A-04 - Retry fairness and failure isolation remain incomplete

- **Current severity:** Medium. **Priority:** P1. **Disposition:** OPEN.
- **Boundary:** one failing route/backlog versus progress of other routes sharing a source observer.
- **Source anchors:** `interchain/runtime/iln_observer_retry.go:16-22`, `74-105`, `141-199`; `interchain/runtime/iln_observer_worker.go:128-162`, `185-223`.
- **Evidence:** retry files are immutable, file- and directory-synced before a failed observation is allowed past the shared cursor, and every retry re-enters the normal proof path. This is meaningful protection. However, the source retry budget is consumed in the same route order; there is no persisted rotating route start. Earlier continuously eligible backlogs can prevent later routes from receiving retries. Queue-capacity and corrupt-record failures return errors at the source-group level.
- **Verification:** a bounded local scheduler check showed repeated fully eligible polls spending the entire budget on earlier failing routes while a later recoverable route received no attempt. The clock was advanced by changing local test file timestamps; the test did not reproduce elapsed production time or a live outage. Existing durable-retry and corruption-rejection tests passed. No actual disk-power-loss experiment was performed.
- **Impact:** delayed or indefinitely postponed recovery, and source-wide scanning stoppage at capacity; failed work is retained rather than silently dropped. Existing public/manual quorum recovery is a mitigation, not a proof of autonomous fair progress.
- **Required remediation:** rotate service across routes with a durable or deterministic fair schedule; isolate quarantined corruption/capacity pressure without dropping original work; expose backlog age/capacity and manual recovery procedures. Verify service of a healthy late route under sustained earlier failures before expanding route count.

### NODE-A-05 - External-source authenticity retains a two-operator trust assumption

- **Current severity:** Medium residual architectural risk, conditional on verified operational diversity; High impact remains possible if the assumption fails. **Priority:** P1 evidence/operational gate. **Disposition:** OPEN pending lead-auditor risk acceptance/provenance assessment.
- **Source anchors:** `interchain/config.go:60-78`, `interchain/evm/rpc_evidence_quorum.go:29-94`, `100-123`, `interchain/evm/iln_direct_operation.go:103-149`, `interchain/evm/finality.go:17-70`, `interchain/runtime/iln_direct_signing.go:27-76`, `97-140`.
- **Implemented mitigation:** each witness is pinned to one endpoint for the complete operation. Same-operator URLs do not count as independent witnesses. Exact canonical source-block hash, transaction hash, message, route snapshot, log index, source height, destination and validator fee are compared. One malicious response or one available operator is insufficient. Base/Arbitrum must supply a valid `safe` head and matching numeric canonical block; there is no fallback to `latest` for those chains. Native XGR uses the local synchronized committed-state adapter.
- **Residual:** a matching pair is accepted as soon as it is found; this is not a majority vote over all configured providers, and an earlier contradictory observation is not a global veto. The code cannot prove that two operator labels correspond to independent upstream data. Two correlated providers can present consistent false source evidence. The BLS validator quorum does not remove correlated evidence risk when honest validators consume the same compromised pair.
- **Verification:** existing witness/finality tests passed. Local injected-reader checks covered one inconsistent provider with two honest witnesses, duplicate operator labels, one surviving operator, two conflicting observations, and two correlated matching observations. The injected-reader tests establish witness-combination behavior; they do not constitute a forged real RPC receipt or creation of a production-valid BLS authorization. A later-added scenario with an honest disagreement preceding a matching pair was **not executed** after the interruption; its behavior is established by static control flow only.
- **Required controls:** independently establish provider/upstream diversity; monitor evidence disagreements and availability; maintain fail-closed signing; accept the distinction between L2 safe confirmation and final Ethereum settlement explicitly. A different architecture is not automatically required by this source review.

## Verified positive invariants

1. `signDirectILNMessage` is reached by automatic observation, public quorum requests and peer authorization hints; it performs synchronization checks before evidence collection and immediately before local signing. Source 1643 uses local committed blocks/receipts; external chains use the complete two-operator witness function.
2. The Direct-BLS payload has a fixed domain and exact binary length. It binds source chain/domain, route, source registry/gateway/router/mailbox, current destination set, message ID, fee, destination router, destination ISM and destination registry. Truncated/extra data are rejected.
3. Source receipts must be successful, correspond to the operation transaction/height, contain exactly one matching fee-qualified gateway operation and exactly one bound canonical mailbox dispatch. Unrelated canonical dispatches in the same transaction are supported; duplicate matching events are rejected.
4. Local signers and accepted individual votes must be active in local PoS and match the destination registry's BLS key. Current set ID and destination delivery state are rechecked; on-chain enforcement remains necessary at execution time.
5. Aggregation uses distinct signer indices and `ceil(2n/3)`. Out-of-range signer bits, insufficient quorum and malformed signatures fail. This is an unweighted Interchain threshold, separate from ordinary stake-weighted PoS consensus.
6. Completed-quorum import verifies the aggregate, current destination set, domain and archive consistency. It does not create new local votes and is not a source-witness bypass for signing.
7. Shared observers use bounded windows and source-local cursors. Full proof validation remains separate from discovery hints. Failed verification is journaled before advancement; normal retry re-verifies all evidence.
8. RPC transport has real cancellation deadlines, a response-size bound, per-provider cooldowns, and no automatic transaction rebroadcast from the read-failover layer. Optional Interchain work is outside the IBFT proposal-verification hooks. Existing cancellation and race tests passed; this does not prove global workload isolation.
9. Fee-governance proposal receipt does not automatically approve it; creating a governance signature requires a local approval action. Membership admission binds local PoS identity and possession of the candidate BLS key.
10. Membership payloads omit the exact destination registry address. The compiled single active registry per chain is therefore an operational invariant; simultaneous same-domain/same-key registries require separate review. Direct message payloads do bind their destination registry/ISM.

## Executed verification and evidence

### Existing source regression suite

Command category: Go 1.23.11, `go test -count=1 -json ./interchain/... ./consensus/ibft/interchain/...` against the local frozen-source test copy.

- **127 existing tests passed** across five packages; no failures or skips in the completed run.
- Public-safe log: `evidence/node/tests-standard.jsonl`.
- SHA-256: `c6dd12ee57dbf24fc983df542c93beefdb51fb584525231acaf6ae24d1469049`.
- Size: 115287 bytes.

### Existing concurrency/race suite

Command category: `go test -race -count=1 -json ./interchain/runtime ./interchain/evm`.

- **102 existing tests passed under the race detector** across two packages; these are a subset re-executed from the existing suite, not 102 additional distinct tests.
- Public-safe log: `evidence/node/tests-race.jsonl`.
- SHA-256: `1c5abfe6bca1b1a4cbf3c019e0d8c21e022579b132d4aeee42615d876e5a7ef1`.
- Size: 92088 bytes.

### Additional checks and boundaries

Before the automated security interruption, bounded local checks completed for witness-combination behavior, gossip admission order, retry scheduling and accounting. Detailed accounting outputs and runnable auditor test material are **not public-safe evidence** and have been separated under access-restricted local work files. The lead auditor must archive any retained confidential evidence in appropriate persistent access-controlled storage before claiming durable confidential archival.

The first standard-suite attempt failed because this execution sandbox prohibited loopback mock sockets. The subsequent explicitly authorized local-loopback run passed. The first attempt is a tooling limitation, not a source security failure.

An automated cybersecurity filter then stopped further exploit-oriented reproduction. This workstream complied by stopping that work and preparing this sanitized defensive summary. No live-chain transaction, malicious block proposal, value transfer, deployment or production configuration change occurred. No test result is asserted for scenarios not present in the saved completed logs.

## Coverage limits and launch requirements

- Current installed production binaries, operator key custody, live validator membership, deployed contract hashes, and provider upstream independence were not established by this node workstream.
- Source/compiled-release correspondence is separate from installed-runtime correspondence. The lead auditor obtained published release build metadata; this review does not substitute that for host measurements.
- No complete adversarial multi-validator network acceptance experiment was performed for the accounting issue, and further exploitation work was stopped after the automated security interruption.
- No full-state disk-power-loss experiment, production load test, formal cryptographic proof, or exhaustive all-package node audit was completed.
- The 127 passing Interchain tests and 102 race-test executions do not negate the independently identified native accounting boundary.
- Recommended launch gate from this workstream: resolve NODE-A-01 or provide independently verified evidence that the currently deployed execution/consensus path is different and safe; fix or expressly constrain the other reliability issues before scaling. The overall launch verdict is the lead auditor's integrated decision.
