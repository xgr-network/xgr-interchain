# Supplementary live route and immutable-binding observations

Source: `xgr-network/xgr-interchain`, `main`, `ffc24139738bcb25ab516e5d3242f258a75fcfb8`. All calls were read-only. The block heights and hashes are the same independently recorded per-chain snapshots used by the parent probe, and remained unchanged before and after the supplementary calls.

## Results

- **8 registered routes, 6 asset representations, 424 getter/balance observations.** 393 comparisons match expected manifest/configuration/cross-getter bindings, 0 mismatches, and 31 balances/counters retained as descriptive observations without a fixed external expected value.
- For every route, destination `verifyInboundRoute` accepts the registered source chain/domain/router/route and rejects an altered route ID and an altered source router: **8 valid, 8 wrong-route rejections, 8 wrong-router rejections**.
- Router owner is zero for all six representations. Registry, Mailbox, hook, ISM, remote router, route ID, chain/domain, factory/deployer, scale and configured default destination gas bindings match. The ARB collateral token/underlying getter matches the canonical token address in the frozen asset configuration.
- All 8 fee vault balances cover their observed allocated-minus-claimed liability. Registry/vault validator set IDs are 1 with three recipients. The route fee is a current governance value cross-checked against the gateway getter, rather than assumed equal to a permanent deployment constant.
- Both public-key encodings were read on all three chains: **6 validator-set reads**, correct manifest address ordering, correct key lengths, unique nonzero keys, and matching key bytes across chains. This does not establish separate private-key control or organizations.
- All **3 execution gateway quote digests** match an independently computed EIP-712 digest for the configured chain ID, contract address, name and version. This behaviorally checks the private cached domain at the observed chain IDs. A chain-ID change/fork was not live-tested.

## Registered route coverage

| Asset | Source | Destination | Valid inbound | Wrong ID/router rejected | Fee-vault liabilities covered |
|---|---|---|---|---|---|
| XGR | XGRChain | Arbitrum | Yes | Yes / Yes | Yes |
| XGR | XGRChain | Base | Yes | Yes / Yes | Yes |
| XGR | Arbitrum | XGRChain | Yes | Yes / Yes | Yes |
| XGR | Base | XGRChain | Yes | Yes / Yes | Yes |
| ARB | XGRChain | Arbitrum | Yes | Yes / Yes | Yes |
| ARB | Arbitrum | XGRChain | Yes | Yes / Yes | Yes |
| ARB | XGRChain | Base | Yes | Yes / Yes | Yes |
| ARB | Base | XGRChain | Yes | Yes / Yes | Yes |

## Arbitrum activation-block interpretation

An initial comparison of `activationBlock()` with the receipt's RPC `blockNumber` produced three numerical differences. Arbitrum EVM `block.number` represents the parent-chain number, whereas RPC receipt `blockNumber` is the L2 number. Each getter **exactly matches the independently fetched canonical creation receipt's `l1BlockNumber`**:

| Component | RPC L2 creation block | `activationBlock()` = receipt L1 block |
|---|---:|---:|
| Source registry | 517836903 | 26262490 |
| XGR route gateway | 517842997 | 26262630 |
| ARB route gateway | 517840879 | 26262581 |

All three historical receipt block hashes match their canonical headers. Raw initial comparisons remain in the JSON as `initialNaiveL2Comparison`; no discrepancy is silently discarded. Official interpretation: [Arbitrum block numbers and time](https://docs.arbitrum.io/arbitrum-essentials/arbitrum-vs-ethereum/block-numbers-and-time). Any scanner using these values must still distinguish L1 activation number from L2 log-scan height; this report does not assert that every downstream scanner was checked here.

## Principal observations and limits

At the respective pinned blocks, XGR synthetic supply is 130 XGR on Arbitrum and 85 XGR on Base. The native XGR router holds 215 XGR with aggregate pending native claims of zero. ARB collateral and both corresponding synthetic supplies are zero. These numbers are consistent at the sampled heights but **do not prove global conservation**: per-chain block times differ and all in-flight messages have not been reconciled.

The getter checks supplement the runtime comparison in `evidence/contracts/runtime-comparison.json`: all 57 runtimes had no unexplained instruction-byte differences after separately excluding compiler-declared immutable spans and precisely identified IPFS metadata digest positions. This is not exact metadata reproduction. Unexposed construction-time fields without an independently decoded input remain unverified. Observations use one configured provider per chain and do not prove provider truth.

Complete raw calls, expected values, decoded results, failed-input route checks, balance counters, canonical header checks and the remaining immutable limitations are in `route-configuration.json`. Scripts and run logs are retained with the audit evidence.
