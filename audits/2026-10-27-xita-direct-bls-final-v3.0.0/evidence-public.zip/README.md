# Public audit evidence — XITA, 27 October 2026

This directory contains publication-safe copies and explicitly identified summaries of actual audit evidence. It accompanies the final report; it is not an application checkout or an executable exploit bundle. No production mutation or new application change was performed during curation.

## Frozen source scope

| Repository | Branch | Audited commit |
| --- | --- | --- |
| xgr-network/xgr-interchain | main | ffc24139738bcb25ab516e5d3242f258a75fcfb8 |
| xgr-network/xgr-node | XGR3.0 | 4d341a08baa604c7871e10af8c7c2e2406f4d032 |

`snapshot.json` and the two `*-source-tree.json` files preserve the captured Git tree/blob inventory. They describe 589 interchain blobs and 764 node blobs. They do not silently include later commits. Standard existing tests are represented by their actual named logs; new confidential reproducer source and dependency trees are excluded.

## Reading the results

`verification-summary.json` retains each measurement's own unit. There is deliberately no overall pass total. The 102-case race run repeats part of the 127-case node suite. The seven final independent/isolation Solidity tests contain six auditor tests and one adjusted existing fixture; 257 fuzz iterations belong to one property. Passing a negative reproducer can confirm an open defect.

The unmodified Solidity suite still has one fixture failure (102/103 pass). Browser-side unit files have 273/280 pass: five stale assertions and two unavailable-Chromium failures. The indexer has 136/137 pass with one stale rejection expectation. None of those failures is removed by the public summary. `node/tests-initial.jsonl`, `contracts/forge-full.log`, `contracts/independent-initial-summary.json` and the initial probe/file-level logs retain setup/fixture outcomes separately from completed reruns.

SQL evidence uses PGlite 0.5.12 and actual PostgreSQL SQL behavior, migrations and exported functions. It does not attest separate-process PostgreSQL concurrency, installed roles or production failure recovery. Some existing concurrency-labelled JavaScript tests use a fake pool. Read-only live observations do not establish an installed-binary hash for every validator, independent RPC truth, a paid empty-gas journey or all-time supply conservation.

## Provenance and normalization

`MANIFEST.json` inventories every staged evidence entry except the manifest itself, with byte length, SHA-256, source-record hashes and the applied transformation. Normal copied logs retain their result text and counts. Ordinary absolute workspace/runtime paths are replaced with `AUDIT_WORKSPACE/`, `DEPENDENCY_WORKSPACE/`, `RUNTIME_HOME/` or `TEMP_DIRECTORY/`; repository-relative source paths and Git tree contents remain unchanged. Source-file hashes and transformed-copy hashes are distinguished.

`phase-a-findings.md`, the four component records under `phase-a/`, and `phase-a-freeze.json` are byte-identical frozen records. The original filenames in the freeze identify those source records; the manifest maps their publication paths. Phase A precedes historical reassessment and can contain preliminary judgments or facts explicitly corrected by the final report. In particular, the published release embeds Go 1.23.12, while the local audit test toolchain was Go 1.23.11; `node-release-buildinfo-summary.json` retains that distinction.

`contracts/admin-reassessment-summary.json` and `contracts/deferred-native-ui-summary.json` are derived from the actual executed offline records. They preserve observed results and limitations while omitting full synthetic fixture inputs. The original source-record hashes remain in the manifest. `publication-omissions.json` documents all omitted categories and replaced raw records. It does not assert that the public folder contains the confidential archive.

## Main evidence groups

| Group | Contents |
| --- | --- |
| `node/` | Existing standard/race logs, initial setup log, source correction/ancestry metadata, static transport review and observed release-version output |
| `contracts/` | Unmodified Solidity baseline, final independent/isolation results, initial fixture summary, dependency/build fingerprints, runtime comparison and normalized current admin/UI checks |
| `sponsorship/` | Managed-relay and targeted administration tests, bounded negative-check logs, SQL semantics, exact corrective PR metadata and historical reassessment checks |
| `ui/` | All 39 per-file named test logs, summary and initial reporter outputs, including the actual failed assertions and browser setup failures |
| `indexer/`, `relayer/` | Current existing suites and bounded historical-regression results |
| `live/` | Public GET/JSON-RPC observations at pinned blocks, configuration checks and supplement records |
| Root provenance files | Git trees, source freeze, published release digests and normalized embedded build provenance |

The manifest does not grant permission to execute confidential fixtures, deploy code, send transactions or infer that a merged source correction has been released to every host.

## Final finding inventories

`current-findings.json` contains the 29 consolidated current findings. `historical-findings.json` retains 43 historical identities from the two prior audit dates with their individual current assessments. These are byte-identical copies of the lead auditor's final normalized inventories after QA, not copies of raw historical documents. Current severity, original severity, remediation status and production verification remain separate concepts. The frozen Phase A records retain their original bytes even where final reassessment corrects or narrows them.
